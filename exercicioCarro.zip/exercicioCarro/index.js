var carro = {
    //ATRIBUTOS
    nome: 'Roadster',
    marca: 'Tesla',
    anoFabricacao: 2021,
    cores: {
        solidas: ['Preto','Branco'],
        metalicas: ['Azul','Vermelho','Verde'],
        perolizadas: ['Preto','Verde'],
    },
    preco: 1000000.00,
    prontoEntrega: false,

    //METODOS
    compra () {
        console.log('Veículo: ' + this.nome + 'Marca: ' + this.marca + 'Ano: ' + this.anoFabricacao + 'Preço: ' + this.preco);
    },
    
    getCores() {
        console.log('Cor: ' + this.cores.metalicas[0]);
    }

}